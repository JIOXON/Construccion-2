package app.addapters.persons;

import app.domain.models.Person;
import app.ports.PersonPort;

public class PersonAdapter implements PersonPort{

	@Override
	public boolean existPerson(long document) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void savePerson(Person person) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Person findByDocument(long document) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
