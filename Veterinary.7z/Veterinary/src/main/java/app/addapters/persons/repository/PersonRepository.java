package app.addapters.persons.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import app.addapters.persons.entity.PersonEntity;

public interface PersonRepository extends JpaRepository<PersonEntity, Long> {

}
