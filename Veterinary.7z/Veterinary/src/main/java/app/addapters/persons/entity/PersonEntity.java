package app.addapters.persons.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "person")
public class PersonEntity {
	@Id
	@Column(name ="id")
	private long person_id;
	@Column(name = "document")
    private long document;
	@Column(name ="age")
    private int age;
	@Column(name = "role")
    private String role;
    @Column(name = "name")
    private String name;
    
    public long getPerson_id() {
        return person_id;
    }
    
    public long getDocument() {
        return document;
    }

    public int getAge() {
        return age;
    }

    public String getRole() {
        return role;
    }

    public String getName() {
        return name;
    }

    public void setDocument(long document) {
        this.document = document;
    }
    
    public void person_id(long person_id) {
        this.person_id = person_id;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PersonEntity() {
    }
}
