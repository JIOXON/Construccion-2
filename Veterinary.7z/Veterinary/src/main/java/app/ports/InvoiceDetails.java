package app.ports;

import java.util.List;
import app.domain.models.Person;

public interface InvoiceDetails {
	public List<InvoiceDetails> getAllInvoices();

    public List<InvoiceDetails> getInvoicesByPerson(Person person);

	public void save(InvoiceDetails invoiceDetails);
}
