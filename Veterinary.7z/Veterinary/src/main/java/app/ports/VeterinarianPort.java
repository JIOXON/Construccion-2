package app.ports;

public interface VeterinarianPort {
    
}
