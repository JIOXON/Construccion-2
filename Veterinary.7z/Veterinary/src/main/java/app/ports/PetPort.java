package app.ports;

import app.domain.models.Pet;
import app.domain.models.Person;

public interface PetPort {

	public Pet findByPersonId(Person personId);
	public void save(Pet pet);
	public Pet findById(long petId);
}
