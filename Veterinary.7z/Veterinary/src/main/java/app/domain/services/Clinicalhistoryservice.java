package app.domain.services;

public class Clinicalhistoryservice {
    
    public void clinical_history(){
    

    }
}
