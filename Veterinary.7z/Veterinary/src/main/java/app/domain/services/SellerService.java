package app.domain.services;

import java.util.List;
import app.domain.models.InvoiceHeader;
import app.domain.models.Person;
import app.domain.models.User;
import app.ports.UserPort;
import app.ports.InvoiceHeaderPort;
import app.ports.PersonPort;

public class SellerService{
	
private UserPort userPort;
private PersonPort personPort;
private InvoiceHeaderPort invoiceHeaderPort;

public List<InvoiceHeader> getInvoiceHeader(Person person)throws Exception{
    if(person==null){
        return invoiceHeaderPort.getAllInvoices();
    }
    person=personPort.findByDocument(person.getDocument());
    if (person==null){
        throw new Exception("no existe una persona con esa cedula");
    }
    User user=userPort.findByPersonId(person);
    if (user==null){
        throw new Exception("no existe un usuario asociado");
    }
}
}