package app.domain.models;

public class InvoiceDetails extends PetOwner{
    private InvoiceHeader invoiceHeader;
    private String description;
    
    public InvoiceHeader getInvoiceHeader() {
        return invoiceHeader;
    }

    public String getDescription() {
        return description;
    }

    public void setInvoiceHeader(InvoiceHeader invoiceHeader) {
        this.invoiceHeader = invoiceHeader;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public InvoiceDetails() {
    }
}
