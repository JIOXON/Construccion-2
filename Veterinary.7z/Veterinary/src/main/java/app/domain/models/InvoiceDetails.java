package app.domain.models;

public class InvoiceDetails extends PetOwner{
    private InvoiceHeader invoiceHeader;
    private String description;
    private long InvoiceDatail_id;
    
    public InvoiceHeader getInvoiceHeader() {
        return invoiceHeader;
    }

    public String getDescription() {
        return description;
    }

    public long getInvoiceDatail_id() {
        return InvoiceDatail_id;
    }

    public void setInvoiceHeader(InvoiceHeader invoiceHeader) {
        this.invoiceHeader = invoiceHeader;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setInvoiceDatail_id(long InvoiceDatail_id) {
        this.InvoiceDatail_id = InvoiceDatail_id;
    }

    public InvoiceDetails() {
    }
}
