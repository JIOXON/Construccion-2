package app.domain.models;

import app.domain.models.User;

public class User extends Person{
    private long user_id;
    private String userName;
    private String Password;
    
    public long getUser_id() {
        return user_id;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public User() {
    }
}
