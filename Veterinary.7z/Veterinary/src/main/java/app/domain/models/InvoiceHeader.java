package app.domain.models;

import java.sql.Date;

public class InvoiceHeader extends PetOwner{
    private long invoice_id;
    private long order_id;
    private String product;
    private double worth;
    private long amount;
    private Date date_Invoice;
    private Person person;
    private PetOwner petowner;
    
    public long getInvoice_id() {
        return invoice_id;
    }

    public long getOrder_id() {
        return order_id;
    }

    public String getProduct() {
        return product;
    }

    public double getWorth() {
        return worth;
    }

    public long getAmount() {
        return amount;
    }

    public Date getDate_Invoice() {
        return date_Invoice;
    }

    public Person getPerson() {
        return person;
    }

    public PetOwner getPetowner() {
        return petowner;
    }

    public void setInvoice_id(long invoice_id) {
        this.invoice_id = invoice_id;
    }

    public void setOrder_id(long order_id) {
        this.order_id = order_id;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setWorth(double worth) {
        this.worth = worth;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public void setDate_Invoice(Date date_Invoice) {
        this.date_Invoice = date_Invoice;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void setPetowner(PetOwner petowner) {
        this.petowner = petowner;
    }

    public InvoiceHeader() {
    }
}
