package app.domain.models;


import java.sql.Date;

public class PetOwner extends Person{
	private String pet_name;
	private String characteristics;
    private String species;
    private String breed;
    private String weight;
    private int pet_age;
    private long owner_id;
    private long pet_id;
    private Date register;
    
    

    public String getCharacteristics() {
        return characteristics;
    }
    
    public String getPet_name() {
        return pet_name;
    }

    public String getSpecies() {
        return species;
    }
    
    public int getPet_age() {
        return pet_age;
    }

    public String getBreed() {
        return breed;
    }

    public String getWeight() {
        return weight;
    }

    public Date getRegister() {
        return register;
    }

    public long getOwner_id() {
        return owner_id;
    }

    public long getPet_id() {
        return pet_id;
    }

    public void setCharacteristics(String characteristics) {
        this.characteristics = characteristics;
    }
    
    public void setPet_name(String pet_name) {
        this.pet_name = pet_name;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
    
    public void setPet_age(int pet_age) {
        this.pet_age = pet_age;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setRegister(Date register) {
        this.register = register;
    }

    public void setOwner_id(long owner_id) {
        this.owner_id = owner_id;
    }

    public void setPet_id(long pet_id) {
        this.pet_id = pet_id;
    }

    public PetOwner() {
    }

}
