package app.adapters.pets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.adapters.persons.entity.PersonEntity;
import app.adapters.pets.Entity.PetEntity;
import app.adapters.pets.Repository.PetRepository;
import app.domain.models.Person;
import app.domain.models.Pet;
import app.ports.PetPort;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@Service
public class PetAdapter implements PetPort {
	
	@Autowired
	private PetEntity petEntity;
	@Autowired
	private PetRepository petRepository;

	@Override
	public Pet findByPersonId(Person personId) {
		PersonEntity personEntity = personAdapter(personId);
		PetEntity pet = petRepository.findByPersonId(personEntity);
		return adapter(pet);
	}
	@Override
	public void save(Pet petOwner) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Pet findById(long petId) {
		// TODO Auto-generated method stub
		return null;
	}
	

	private Pet adapter(PetEntity pet) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	private PersonEntity personAdapter(Person person) {
		PersonEntity personEntity = new PersonEntity();
		personEntity.setPersonId(person.getPersonId());
		personEntity.setDocument(person.getDocument());
		personEntity.setName(person.getName());
		personEntity.setRole(person.getRole());
		return personEntity;
	}
	


	
}