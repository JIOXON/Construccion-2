package app.domain.services;

import org.springframework.beans.factory.annotation.Autowired;
import app.domain.models.InvoiceHeader;
import app.domain.models.Order;
import app.domain.models.Pet;
import app.ports.InvoiceHeaderPort;
import app.ports.OrderPort;
import app.ports.PetPort;

public class SellerService {

	@Autowired
	private InvoiceHeaderPort invoiceHeaderPort;
	@Autowired
	private PetPort petPort;
	@Autowired
	private OrderPort orderPort;

	public void InvoiceHeader(InvoiceHeader invoice) throws Exception {
		Order order = orderPort.findById(invoice.getOrderId());
		if(order == null) {
			throw new Exception("meter mensaje de error");
		}
		Pet pet = petPort.findById(invoice.getPetId());
		if(pet==null) {
			throw new Exception("meter mensaje de error");
		}	
		invoice.setOrderId(order);
		invoice.setPet_id(0);
		invoiceHeaderPort.save(invoice);
	}
}